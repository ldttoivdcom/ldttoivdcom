var replace = require('replace-in-file');
var package = require('./package.json');

var date = new Date();
var buildVersion = `${package.version}.${date.getFullYear()}${date.getMonth() + 1}${date.getDate()}`;


const options = {
  files: 'src/environments/environment.prod.ts',
  from: /version: '(.*)'/g,
  to: 'version: \'' + buildVersion + '\'',
  allowEmptyPaths: false
};

try {
  let changedFiles = replace.sync(options);
  // console.log(changedFiles);
  if (changedFiles.length && !changedFiles[0].hasChanged) {
    throw 'Please make sure that file \'' + options.files + '\' has "version: \'\'"';
  }
  console.log('Build version set: ' + buildVersion);
} catch (error) {
  console.error('Error occurred:', error);
}

