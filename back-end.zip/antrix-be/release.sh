PROJECT_NAME=$1
RELEASE_NAME=$2
RELEASE_FOLDER=$3
BUILD_BRANCH=$4
COMMIT_MESSAGE=$5

# update version
#cd ./projects/$PROJECT_NAME/
npm --no-git-tag-version version patch
node replace.version.js

# get version
PACKAGE_VERSION=$(cat package.json \
  | grep version \
  | head -1 \
  | awk -F: '{ print $2 }' \
  | sed 's/[",]//g' \
  | tr -d '[[:space:]]')

echo $PACKAGE_VERSION

#cd ../../

# build
#ng build
cross-env NODE_ENV=ldttoivd outputPath=dist-ldttoivd webpack --config webpack.config.js --no-cache
cross-env NODE_ENV=isoai outputPath=dist-isoai webpack --config webpack.config.js --no-cache

## RELEASE
cd ./$RELEASE_NAME

git pull
cd ..

# replace files
#rm -rvf ./$RELEASE_NAME/$RELEASE_FOLDER/*
#cp -rvf ./dist/$PROJECT_NAME/* ./$RELEASE_NAME/$RELEASE_FOLDER/

# be
rm -rvf ./$RELEASE_NAME/*
cp -rRvf ./build/* ./$RELEASE_NAME/
cp -rRvf ./config.env ./$RELEASE_NAME/
cp -rRvf ./src/ssl ./$RELEASE_NAME/src/ssl
cp -rRvf ./src/database ./$RELEASE_NAME/src/database


# commit
cd ./$RELEASE_NAME
git add -A
git commit -m "be build ${RELEASE_FOLDER} ${PACKAGE_VERSION} ${COMMIT_MESSAGE}"
git push -u origin $BUILD_BRANCH
cd ..
