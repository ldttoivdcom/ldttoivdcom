import {Request, Response, NextFunction} from "express";
import HttpException from "../utils/exceptions/error.exception";

function errorMiddleware(
    error: HttpException,
    req: Request,
    res: Response,
    next: NextFunction
) {
    const code = error.code || 500;
    const errorMess = error.error || "Internal Server Error";
    const message = error.message || "Something went wrong";
    res.status(code).send({
        code,
        message,
        error: errorMess,
        data: null,
    });
}
export default errorMiddleware;