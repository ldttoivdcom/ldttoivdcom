import {NextFunction, Request, Response} from "express";
import * as captchaService from "../services/captcha.service";
import HttpException from "../utils/exceptions/error.exception";

export const verifyCaptcha = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const {captcha} = req.body
        if (!captcha) {
            return res.status(400).json({code: 400, message: "Captcha is required", error: null, data: null});
        }
        const result: any = await captchaService.verifyCaptcha(captcha)
        if (!result) {
            return res.status(400).json({code: 400, message: "Captcha is invalid", error: null, data: null});
        }
        if (result['success']) {
            next()
        } else {
            return res.status(400).json({code: 400, message: "Captcha is invalid", error: null, data: null});

        }
    } catch (e: any) {
        next(new HttpException(500, e.message, 'Verify captcha failed'))
    }
}