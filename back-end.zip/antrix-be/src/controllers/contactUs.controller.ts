import nodeMailer from 'nodemailer';
import * as mailTemplate from '../views/mailTemplate';
import * as mailServices from '../services/mail.service';
import {NextFunction, Request, Response} from 'express';
import HttpException from "../utils/exceptions/error.exception";
export const contactUs = async (req: Request, res: Response, next: NextFunction) => {
   try {
       const {formType} = req.query;
       if (!req.body) {
           return res.status(400).json({code: "400", error: null, message: "Data is required"});
       }
        const reqData = req.body;
        await mailServices.sendMail(reqData,formType?.toString());
        return res.status(200).json({code: "200", error: null,  message: "Thank you for contacting us"});
   }catch (e: any) {
       next(new HttpException(500, e.message, 'Contact Us failed'))
   }
}