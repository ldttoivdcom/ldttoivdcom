import {mailTemplate} from "../views/mailTemplate";
import * as config from "../config/config";
import nodemailer from "nodemailer";
import {IInputMailData} from "../interfaces/mail.interface";


export const sendMail = async (reqData: IInputMailData, formType?: string) => {
    const {
        email,
        prodService,
    } = reqData;
    let company = 'Antrix'
    let contactMail = 'support@antrix.com'
    if (config.NODE_ENV === 'isoai') {
        company = 'ISOAI'
        contactMail = 'support@isoai.ai'
    } else if (config.NODE_ENV === 'ldttoivd'|| config.NODE_ENV === 'ldttoivd-ai') {
        company = 'LDTtoIVD'
        contactMail = 'support@ldttoivd.ai'
    }
    const thanksTitle = `Thank you for submitting the form.`;
    const topContent = `Thank you for reaching out to us. We appreciate your interest in ${company}. Your inquiry about Product / Service: ${prodService || ""} is important to us, and we will make every effort to respond as quickly as possible. `
    const bottomContent = `Our team will review your message and get back to you shortly. If your
                          inquiry is urgent, please feel free to contact us directly at ${contactMail}.`
    const ps = `Thank you for considering ${company}. We look forward to assisting you.`
    reqData.thanksTitle = thanksTitle;
    reqData.topContent = topContent;
    reqData.bottomContent = bottomContent;
    reqData.ps = ps;
    reqData.contactMail = contactMail;
    let transporter = nodemailer.createTransport({
        host: config.SENDER_HOST,
        port: Number(config.SENDER_HOST_PORT),
        secure: false,
        auth: {
            user: config.SENDER,
            pass: config.SENDER_PASSWORD
        },
    });
    console.log(config.SENDER_CC)
    await transporter.sendMail({
        from: config.SENDER,
        to: [email, config.NODE_ENV === 'ldttoivd-ai' ? config.SENDER : ''],
        cc: config.SENDER_CC?.split(','),
        subject: config.SENDER_SUBJECT,
        html: mailTemplate(reqData, undefined, undefined, undefined, formType)
    });

}