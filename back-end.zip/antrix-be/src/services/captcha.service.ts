import {CAPTCHA_SECRET_KEY} from "../config/config";

export const verifyCaptcha = async (captcha: string) => {
    const result = await fetch(`https://www.google.com/recaptcha/api/siteverify?secret=${CAPTCHA_SECRET_KEY}&response=${captcha}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
    })
    return result.json()
}