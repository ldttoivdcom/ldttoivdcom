export interface ServerConfig {
    HTTP_PORT: number;
    HTTPS_PORT: number;
    sslKeyPath: string;
    sslCertPath: string;
}
