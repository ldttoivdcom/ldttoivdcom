import {Router} from "express";

interface IRoute {
    path: string;
    router: Router;
}
export default IRoute;