import * as config from "../config/config";
import {IInputMailData} from "../interfaces/mail.interface";
import {NODE_ENV} from "../config/config";

export const mailTemplate = (reqData: IInputMailData, yourCompanyName = "Antrix", yourContactInformation?: string, additionalContact?: string, formType?: string) => {
    let imgUrl = `${config.IMAGE_BASE_URL}dropdown_header_navigation.png`
    let footerAddress = `
    <p style="margin: 9px 0">${yourCompanyName}, Inc819 Peekskill DrSunnyvale, CA 94087</p>
                <a href="www.${yourCompanyName?.toLowerCase()}.${config.NODE_ENV == 'ldttoivd-ai' ? 'ai' : 'com'}" style="margin: 9px 0">www.${yourCompanyName?.toLowerCase()}.com</a>`
    if (config.NODE_ENV == 'ldttoivd' || config.NODE_ENV == 'ldttoivd-ai') {
        yourCompanyName = "LDTtoIVD";
        imgUrl = `${config.IMAGE_BASE_URL}lvd-header.png`
        reqData.bottomContent = "LDTtoIVD is committed to protecting and respecting your privacy, and we’ll use your personal information to administer your account and to provide the products and services you requested from us. "
        footerAddress = ''
    } else if (config.NODE_ENV == 'isoai') {
        yourCompanyName = "ISOAI&#8203;.AI";
        reqData.bottomContent = "ISOAI is committed to protecting and respecting your privacy, and we’ll use your personal information to administer your account and to provide the products and services you requested from us."
        imgUrl = `${config.IMAGE_BASE_URL}iso-header.png`
        footerAddress = ''

    }
    const moreFieldsForIsoai = `
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span><strong>Product Name:</strong> ${reqData.productName || ""}</span></td>
    </tr>
     <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span><strong>Product Industry Sectors:</strong> ${reqData.productIndustrySectors || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span><strong>Product Description:</strong> ${reqData.productDescription || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span><strong>Product / Component :</strong> ${reqData.productComponent || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span><strong>Please provide information about your specific challenge or question:</strong> ${reqData.challengeOrQuestion || ""}</span></td>
    </tr>

 `

    const moreFieldsForLdttoivd = `
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Product Name: </strong> ${reqData.productName || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>IVD Specialty: </strong> ${reqData.IVDSpecialty || ""}</span></td>
    </tr>
     <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>IVD Application: </strong> ${reqData.IVDApplication || ""}</span></td>
    </tr>
            <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>US FDA Product Classiflication: </strong> ${reqData.USFDA || ""}</span></td>
    </tr>
     <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Global Medical Device Nomenclature (GMDN): </strong> ${reqData.gmdn || ""}</span></td>
    </tr>
        <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>US FDA 21 CFR Citation Code: </strong> ${reqData.USFDA21Code || ""}</span></td>
    </tr>
           <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>US FDA Product Code: </strong> ${reqData.USFDACode || ""}</span></td>
    </tr>
         <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>US FDA Product Predicate Device Number: </strong> ${reqData.USFDAproductPredicateDevice || ""}</span></td>
    </tr>
    </tr>
         <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>US FDA Predicate Name: </strong> ${reqData.productPredicateDevice || ""}</span></td>
    </tr>
    
            <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>EU 2017/746 IVDR Classification Rule: </strong> ${reqData.EU2017Rule || ""}</span></td>
    </tr>
                <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>EU 2017/746 IVDR Codes: </strong> ${reqData.EU2017Code || ""}</span></td>
    </tr>
        <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>EMDN Code: </strong> ${reqData.emdn || ""}</span></td>
    </tr>
          <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>EU 2017/746 IVDR Classification: </strong> ${reqData.EUIVDR || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> Product Intended Use / Intended Purpose: </strong> ${reqData.productIntendedUse || ""}</span></td>
    </tr>
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> What is detected and/or measured: </strong> ${reqData.detectedOrMeasured || ""}</span></td>
    </tr>
   <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> Intended Function: </strong> ${reqData.intendedFunction || ""}</span></td>
    </tr>
       <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> pecific information that is intended to be provided in the context of: </strong> ${reqData.specificInformation || ""}</span></td>
    </tr>
       <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> Testing Process: </strong> ${reqData.testingProcess || ""}</span></td>
    </tr>
       <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong> Test Result Type: </strong> ${reqData.testResultType || ""}</span></td>
    </tr>
   

      <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>LDTtoIVD IRIS Wizard - Check draft documents to be created by AI and ML models: </strong> ${reqData.prodService || ""}</span></td>
    </tr>
                <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Medical Disease / Condition Detecte: </strong> ${reqData.medicalDisease || ""}</span></td>
    </tr>
       <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Specimen Type: </strong> ${reqData.specimen || ""}</span></td>
    </tr>
            <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Product / Device Components for e.g. Reagents, Instrument, Software, Accessories: </strong> ${reqData.productComponent || ""}</span></td>
    </tr>
     
    <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Product Description: </strong> ${reqData.productDescription || ""}</span></td>
    </tr>
        <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Test Principle: </strong> ${reqData.testPrinciple || ""}</span></td>
    </tr>
    
                       <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Benefit - Risk Summary: </strong> ${reqData.BRSummary || ""}</span></td>
    </tr>
    
                         <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Clinical Study Patient Demographic Parameters Summary: </strong> ${reqData.clinicalStudy || ""}</span></td>
    </tr>
                     <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Software Verification and Validation Summary: </strong> ${reqData.softwareVerification || ""}</span></td>
    </tr>
                 <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Design Verification and Validation Summary: </strong> ${reqData.designVerification || ""}</span></td>
    </tr>
        <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Manufacturing Summary: </strong> ${reqData.manufacturingSummary || ""}</span></td>
    </tr>
        <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Select quality and regulatory governance documents to be generated by the LDTtoIVD IRIS AI Agent: </strong> ${reqData.qualityAndRegulatoryGovernance || ""}</span></td>
    </tr>
         <tr>
            <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Please provide information about your specific challenge or question: </strong> ${reqData.challengeOrQuestion || ""}</span></td>
    </tr>

    `
    return `

<!DOCTYPE html>
<html lang="">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <title>${config.TITLE_MAIL_TAB}</title>
</head>
<body style="margin: 0; font-family: 'Poppins', sans-serif; background-color: #f5f5f5;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="max-width: 640px; background-color: white;">
        <tr>
            <td style="text-align: center; background-color: #0C3C60;">
                <img src="${imgUrl}" alt="header" style="width: 100%; height: auto; border: 0;"/>
            </td>
        </tr>

        <tr>
            <td style="padding: 32px; font-size: 16px; line-height: 24px; color: #333333;">
                <p style="text-align: center; margin: 12px 0 0 0">
                    <img src="${config.IMAGE_BASE_URL}check_circle.png" alt="tick" style="width: 32px; height: 32px; border: 0;">
                </p>
                <p style="text-align: center; font-weight: 600; font-size: 24px; color: #0C3C60; margin: 15px 0 22px 0;">
                    ${reqData.thanksTitle}
                </p>
                <p style="border-top: 1px solid #EAECF0; padding-top: 15px;color: #333333">
                    Dear ${reqData.firstName || ""},
                </p>
                <p style="margin: 9px 0;color: #333333">${reqData.topContent}</p>
                <p style="margin: 0 0 9px 0;color: #333333">Here are the details you provided:</p>

                <table style="width: 100%; background-color: #F9FAFB;">
                    <tr>
                        <td >
                            <table style="margin-left: 12px;color: #333333">
                                 <tr style="">
                                    <td style="text-align: left; padding-left: 12px ;padding-top: 12px; width: 100%"><span> <strong>First Name: </strong> ${reqData.firstName || ""}</span></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Last Name: </strong> ${reqData.lastName || ""}</span></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Email: </strong> ${reqData.email || ""}</span></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Telephone: </strong> ${reqData.phone || ""}</span></td>
                                </tr>
                              <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Company: </strong> ${reqData.company || ""}</span></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Job Title: </strong> ${reqData.jobTitle || ""}</span></td>
                                </tr>
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Company Website: </strong> ${reqData.companyWeb || ""}</span></td>
                                </tr>
                                ${(config.NODE_ENV == 'isoai' || config.NODE_ENV == 'ldttoivd' || config.NODE_ENV == 'ldttoivd-ai') && formType != 'normal' ? `
                                 <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Company Address: </strong>${reqData.companyAddress || ""}</span></td>
                                </tr>
                                ` : ''}
                                ${reqData.prodService ? `
                                <tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Product / Service: </strong>${reqData.prodService || ""} </span></td>
                                </tr>` : ""}
                                ${reqData.partNo ? `<tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Part Number: </strong>${reqData.partNo || ""}</span></td>
                                </tr>` : ""}
                                ${reqData.pricing ? `<tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px"><span> <strong>Pricing: </strong>${reqData.pricing || ""}</span></td>
                                </tr>` : ""}
                                ${reqData.message ? `<tr>
                                    <td style="text-align: left; padding-left: 12px ; padding-top: 15px; padding-bottom: 12px"><span> <strong>Message:</strong> ${reqData.message || ""}</span></td>
                                </tr>` : ""}
                                
                                ${(config.NODE_ENV == 'ldttoivd' || config.NODE_ENV == 'ldttoivd-ai') && formType != 'normal' ? moreFieldsForLdttoivd : ''}
                                ${config.NODE_ENV == 'isoai' && formType != 'normal' ? moreFieldsForIsoai : ''}
                            </table>
                        </td>
                    </tr>

                </table>

                <p style="margin: 9px 0; color: #333333">${reqData.bottomContent}</p>
                <p style="margin: 9px 0; color: #333333">${reqData.ps}</p>
                <p style="margin: 9px 0; color: #333333;">Best Regards,</p>
                <p style="margin: 9px 0; color: #333333">${yourCompanyName || ""} ${yourContactInformation || ""} ${additionalContact || ""}</p>
            </td>
        </tr>

        <tr style="background-color: #EAECF0;">
            <td style="padding: 12px; text-align: center; font-size: 14px;">
                <p style="margin: 9px 0;text-decoration: none; color: #333333;pointer-events: none;">@ ${config.NODE_ENV == 'ldttoivd-ai' ? '2025' : '2023'} ${yourCompanyName}</p>
                ${footerAddress}
            </td>
        </tr>
    </table>
</body>
</html>


    `;
}