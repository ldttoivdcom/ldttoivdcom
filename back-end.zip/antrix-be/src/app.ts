import express, {Application} from "express";
import ErrorMiddleware from "./middlewares/error.middleware";
import https from "https";
import fs from "fs";
import http from "http";
import bodyParser from "body-parser";
import {ServerConfig} from "./interfaces/app.interface";
import cookieParser from "cookie-parser";
import cors from "cors";
import IRoute from "./interfaces/route.interface";

export default class App {
    public express: Application;
    private config: ServerConfig;
    private readonly routes: IRoute[];

    constructor(routes: IRoute[], config: ServerConfig) {
        this.express = express();
        this.express.use(bodyParser.json({limit: '10mb'}));
        this.express.use(bodyParser.urlencoded({limit: '10mb', extended: true}));
        this.express.use(cookieParser());
        this.config = config;
        this.routes = routes;
        this.initializeCors();
        this.initializeLoggerRequest();
        this.initializeRoutes(this.routes);
        this.loadCredentials();

    }

    private initializeRoutes(routes: IRoute[]) {
        routes.forEach((route) => {
            this.express.use("/api", route.router);
        });
    }

    private initializeLoggerRequest() {
        this.express.use((req: { method: any; url: any; }, res: any, next: () => void) => {
            console.log(`${new Date().toISOString()} - ${req.method} request to ${req.url}`);
            next();
        })
    }

    private initializeErrorMiddleware() {
        this.express.use(ErrorMiddleware)
    }

    private initializeCors() {
        const corsOptions = {
            origin: "*",
            credentials: true, //access-control-allow-credentials:true
            optionSuccessStatus: 200,
        };
        this.express.use(cors(corsOptions));
    }
    private loadCredentials(): https.ServerOptions {
        const privateKey = fs.readFileSync(this.config.sslKeyPath, 'utf8');
        const certificate = fs.readFileSync(this.config.sslCertPath, 'utf8');
        return {key: privateKey, cert: certificate};
    }
    public async start() {
        try {
            const credentials = this.loadCredentials();
            const httpServer = http.createServer(this.express);
            const httpsServer = https.createServer(credentials, this.express);

            httpServer.listen(this.config.HTTP_PORT, () => {
                console.log(`App running on port HTTP port ${this.config.HTTP_PORT}...`)
            });

            httpsServer.listen(this.config.HTTPS_PORT, () => {
                console.log(`App running on port HTTPS port ${this.config.HTTPS_PORT}...`);
            });

        } catch (error) {
            console.error("Error starting the application:", error);
            process.exit(1);
        }
    }


}
