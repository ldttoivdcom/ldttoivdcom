import { Response } from 'express';

export default class HttpResponse {
    constructor() {
    }
    public static sendResponse(res: Response, code: number, message: string, data: any=null, error:any=null) {
        return res.status(code).json({code: code, message: message, data: data, error});
    }
}