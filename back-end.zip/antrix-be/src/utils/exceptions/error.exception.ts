class HttpException extends Error {
  public code: number;
  public error: string;
  public message: string;
  constructor(code: number, error: string, message:string) {
    super(error);
    this.code = code;
    this.message = message;
    this.error = error;
  }
}
export default HttpException;