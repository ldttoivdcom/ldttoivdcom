import express from "express";
import IRoute from "../interfaces/route.interface";
import * as imageController from "../controllers/image.controller";

export default class ImageRoute implements IRoute {
    public router = express.Router();
    public path = "/v1/image";

    constructor() {
        this.initializeRoutes();
    }

    public initializeRoutes() {
        this.router
            .get(`${this.path}/:imageName`, imageController.getImage)

    }


}

