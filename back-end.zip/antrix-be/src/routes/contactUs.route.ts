import express from "express";
import * as contactUsController from "../controllers/contactUs.controller";
import IRoute from "../interfaces/route.interface";
import {verifyCaptcha} from "../middlewares/captcha.middleware";

export default class ContactUsRoute implements IRoute {
    public router = express.Router();
    public path = "/v1/contact-us";

    constructor() {
        this.initializeRoutes();
    }

    private initializeRoutes() {
        this.router.post(`${this.path}`, verifyCaptcha, contactUsController.contactUs);
    }
}



