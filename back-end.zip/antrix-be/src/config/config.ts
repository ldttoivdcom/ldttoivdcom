import {config} from "dotenv";

config({
    path: "./config.env",
});


const HTTP_PORT = process.env.HTTP_PORT;
const HTTPS_PORT = process.env.HTTPS_PORT;
const NODE_ENV = process.env.NODE_ENV;
let SENDER,
    SENDER_PASSWORD,
    SENDER_CC,
    SENDER_SUBJECT,
    SENDER_HOST = process.env.SENDER_HOST,
    SENDER_HOST_PORT = process.env.SENDER_HOST_PORT,
    IMAGE_BASE_URL,
    TITLE_MAIL_TAB,
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY,
    SSL_PATH_PRIVATE_KEY,
SSL_PATH_CERTIFICATE;
;
console.log("NODE_ENV", NODE_ENV);
if (NODE_ENV === 'antrix') {
    SENDER = process.env.ANTRIX_SENDER;
    SENDER_PASSWORD = process.env.ANTRIX_SENDER_PASSWORD;
    SENDER_CC = process.env.ANTRIX_SENDER_CC;
    SENDER_SUBJECT = process.env.ANTRIX_SENDER_SUBJECT;
    IMAGE_BASE_URL = process.env.ANTRIX_IMAGE_BASE_URL || process.env.IMAGE_BASE_URL;
    TITLE_MAIL_TAB = process.env.ANTRIX_TITLE_MAIL_TAB;
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY_ANTRIX || process.env.CAPTCHA_SECRET_KEY;
    SSL_PATH_PRIVATE_KEY=process.env.SSL_PATH_PRIVATE_KEY_ANTRIX || './src/ssl/key.pem';
    SSL_PATH_CERTIFICATE=process.env.SSL_PATH_CERTIFICATE_ANTRIX || './src/ssl/cert.pem';

} else if (NODE_ENV === 'isoai') {
    SENDER = process.env.ISOAI_SENDER || process.env.ANTRIX_SENDER;
    SENDER_PASSWORD = process.env.ISOAI_SENDER_PASSWORD || process.env.ANTRIX_SENDER_PASSWORD
    SENDER_CC = process.env.ISOAI_SENDER_CC || process.env.ANTRIX_SENDER_CC;
    SENDER_SUBJECT = process.env.ISOAI_SENDER_SUBJECT || process.env.ANTRIX_SENDER_SUBJECT;
    IMAGE_BASE_URL = process.env.ISOAI_IMAGE_BASE_URL || process.env.IMAGE_BASE_URL;
    TITLE_MAIL_TAB = process.env.ISOAI_TITLE_MAIL_TAB || process.env.ANTRIX_TITLE_MAIL_TAB;
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY_ISOAI || process.env.CAPTCHA_SECRET_KEY;
    SSL_PATH_PRIVATE_KEY=process.env.SSL_PATH_PRIVATE_KEY_ISOAI || './src/ssl/key.pem';
    SSL_PATH_CERTIFICATE=process.env.SSL_PATH_CERTIFICATE_ISOAI || './src/ssl/cert.pem';
} else if (NODE_ENV === 'ldttoivd') {
    SENDER = process.env.LDTTOIVD_SENDER ||  process.env.ANTRIX_SENDER;
    SENDER_PASSWORD = process.env.LDTTOIVD_SENDER_PASSWORD || process.env.ANTRIX_SENDER_PASSWORD;
    SENDER_CC = process.env.LDTTOIVD_SENDER_CC || process.env.ANTRIX_SENDER_CC;
    SENDER_SUBJECT = process.env.LDTTOIVD_SENDER_SUBJECT || process.env.ANTRIX_SENDER_SUBJECT;
    IMAGE_BASE_URL = process.env.LDTTOIVD_IMAGE_BASE_URL || process.env.IMAGE_BASE_URL;
    TITLE_MAIL_TAB = process.env.LDTTOIVD_TITLE_MAIL_TAB || process.env.ANTRIX_TITLE_MAIL_TAB;
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY_LDTTOIVD || process.env.CAPTCHA_SECRET_KEY;
    SSL_PATH_PRIVATE_KEY=process.env.SSL_PATH_PRIVATE_KEY_LDTTOIVD || './src/ssl/key.pem';
    SSL_PATH_CERTIFICATE=process.env.SSL_PATH_CERTIFICATE_LDTTOIVD || './src/ssl/cert.pem';
}else if (NODE_ENV === 'ldttoivd-ai') {
    SENDER = process.env.LDTTOIVD_AI_SENDER ||  process.env.ANTRIX_SENDER;
    SENDER_PASSWORD = process.env.LDTTOIVD_AI_SENDER_PASSWORD || process.env.ANTRIX_SENDER_PASSWORD;
    SENDER_CC = process.env.LDTTOIVD_AI_SENDER_CC || process.env.ANTRIX_SENDER_CC;
    SENDER_SUBJECT = process.env.LDTTOIVD_AI_SENDER_SUBJECT || process.env.ANTRIX_SENDER_SUBJECT;
    IMAGE_BASE_URL = process.env.LDTTOIVD_AI_IMAGE_BASE_URL || process.env.IMAGE_BASE_URL;
    TITLE_MAIL_TAB = process.env.LDTTOIVD_AI_TITLE_MAIL_TAB || process.env.ANTRIX_TITLE_MAIL_TAB;
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY_LDTTOIVD_AI || process.env.CAPTCHA_SECRET_KEY;
    SSL_PATH_PRIVATE_KEY=process.env.SSL_PATH_PRIVATE_KEY_LDTTOIVD_AI || './src/ssl/key.pem';
    SSL_PATH_CERTIFICATE=process.env.SSL_PATH_CERTIFICATE_LDTTOIVD_AI || './src/ssl/cert.pem';
}else {
    //development
    SENDER = process.env.ANTRIX_SENDER;
    SENDER_PASSWORD = process.env.ANTRIX_SENDER_PASSWORD;
    SENDER_CC = process.env.ANTRIX_SENDER_CC;
    SENDER_SUBJECT = process.env.ANTRIX_SENDER_SUBJECT;
    IMAGE_BASE_URL = process.env.ANTRIX_IMAGE_BASE_URL || process.env.IMAGE_BASE_URL;
    TITLE_MAIL_TAB = process.env.ANTRIX_TITLE_MAIL_TAB;
    CAPTCHA_SECRET_KEY = process.env.CAPTCHA_SECRET_KEY_ANTRIX || process.env.CAPTCHA_SECRET_KEY;
    SSL_PATH_PRIVATE_KEY='./src/ssl/key.pem';
    SSL_PATH_CERTIFICATE='./src/ssl/cert.pem';
}


export {
    HTTP_PORT,
    HTTPS_PORT,
    NODE_ENV,
    SENDER,
    SENDER_PASSWORD,
    SENDER_CC,
    SENDER_SUBJECT,
    SENDER_HOST,
    SENDER_HOST_PORT,
    IMAGE_BASE_URL,
    TITLE_MAIL_TAB,
    CAPTCHA_SECRET_KEY,
    SSL_PATH_PRIVATE_KEY,
    SSL_PATH_CERTIFICATE
}