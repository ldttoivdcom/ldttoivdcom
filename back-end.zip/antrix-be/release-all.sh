#!/bin/bash

PROJECT_NAME=$1
COMMIT_MESSAGE=$2


# Update version
npm --no-git-tag-version version patch
node replace.version.js

# Get version
PACKAGE_VERSION=$(grep -m 1 version package.json | awk -F: '{ print $2 }' | sed 's/[",]//g' | tr -d '[[:space:]]')

echo "Updated version: $PACKAGE_VERSION"

# Build for ldttoivd
echo "Building for ldttoivd"
npx cross-env NODE_ENV=ldttoivd outputPath=dist-ldttoivd npx webpack --config webpack.config.js --no-cache
echo "Building for ldttoivd.ai"
npx cross-env NODE_ENV=ldttoivd-ai outputPath=dist-ldttoivd-ai npx webpack --config webpack.config.js --no-cache
echo "Building for isoai"
npx cross-env NODE_ENV=isoai outputPath=dist-isoai npx webpack --config webpack.config.js --no-cache


## RELEASE
cd ./release-isoai

git pull origin origin be-build-isoai
cd ..

rm -rvf ./release-isoai/*
cp -rRvf ./dist-isoai/* ./release-isoai/

# commit
cd ./release-isoai
git add -A
git commit -m "be build release-isoai ${PACKAGE_VERSION} ${COMMIT_MESSAGE}"
git push -u origin be-build-isoai
cd ..

# ldttoivd
cd ./release-ldttoivd

git pull origin be-build-ldttoivd
cd ..

rm -rvf ./release-ldttoivd/*
cp -rRvf ./dist-ldttoivd/* ./release-ldttoivd/

# commit
cd ./release-ldttoivd
git add -A
git commit -m "be build release-ldttoivd ${PACKAGE_VERSION} ${COMMIT_MESSAGE}"
git push -u origin be-build-ldttoivd
cd ..


# ldttoivd-ai
cd ./release-ldttoivd-ai

git pull origin  be-build-ldttoivd-ai
cd ..

rm -rvf ./release-ldttoivd-ai/*
cp -rRvf ./dist-ldttoivd-ai/* ./release-ldttoivd-ai/
# commit
cd ./release-ldttoivd-ai
git add -A
git commit -m "be build release-ldttoivd-ai ${PACKAGE_VERSION} ${COMMIT_MESSAGE}"
git push -u origin be-build-ldttoivd-ai
cd ..
