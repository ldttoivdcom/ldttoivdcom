#!/bin/bash

# Build for ldttoivd
echo "Building for antrix"
npx cross-env NODE_ENV=antrix outputPath=dist-antrix npx webpack --config webpack.config.js --no-cache
echo "Building for ldttoivd.ai"
npx cross-env NODE_ENV=ldttoivd-ai outputPath=dist-ldttoivd-ai npx webpack --config webpack.config.js --no-cache
echo "Building for isoai"
npx cross-env NODE_ENV=isoai outputPath=dist-isoai npx webpack --config webpack.config.js --no-cache


## RELEASE

rm -rvf ./release-isoai/*
cp -rRvf ./dist-isoai/* ./release-isoai/

# antrix
rm -rvf ./release/*
cp -rRvf ./dist-antrix/* ./release/

# ldttoivd-ai

rm -rvf ./release-ldttoivd-ai/*
cp -rRvf ./dist-ldttoivd-ai/* ./release-ldttoivd-ai/
