const Dotenv = require('dotenv-webpack');
const DefinePlugin = require('webpack/lib/DefinePlugin');
const {CleanWebpackPlugin} = require('clean-webpack-plugin');
const CopyPlugin = require('copy-webpack-plugin');
const path = require("path");
module.exports = {
    mode: 'development',
    entry: './server.ts',
    target: 'node',
    externals: {

    },
    module: {
        rules: [
            {
                test: /\.ts$/,
                use: 'ts-loader',
                exclude: /node_modules/
            }
            ,
            {
                test: /\.html$/,
                use: 'html-loader'
            },
            {
                test: /\.cs$/,
                use: 'ignore-loader',
            }
        ]
    },
    resolve: {
        extensions: ['.ts', '.js']
    },
    plugins: [
        new Dotenv({
            path: './config.env'
        }),
        new CleanWebpackPlugin(),
        new DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'development')
        }),
        {
            apply(compiler) {
                compiler.hooks.done.tap('ModuleAndAssetLoggerPlugin', stats => {
                    const modules = stats.toJson({assets: false}).modules; // Modules
                    const assets = stats.toJson().assets;               // Assets
                    if (modules) {
                        console.log('\nBuilt modules:');
                        modules.forEach(module => {
                            const filePath = module.name || module.identifier;
                            if (filePath && !filePath.includes('node_modules')) {
                                console.log(`  - ${filePath} (${module.size} bytes)`);
                            }
                        });
                    }
                    if (assets) {
                        console.log('\nBuilt assets:');
                        assets.forEach(asset => {
                            console.log(`  - ${asset.name} (${asset.size} bytes)`);
                        });
                    }


                });
            }
        },
        new CopyPlugin({
            patterns: [
                {
                    from: path.resolve(__dirname, 'src/ssl'),
                    to: path.resolve(__dirname, `${process.env.outputPath}/src/ssl`)
                }, {
                    from: path.resolve(__dirname, 'src/views/images'),
                    to: path.resolve(__dirname, `${process.env.outputPath}/src/views/images`)
                },
                {
                    from: path.resolve(__dirname, 'package.json'),
                    to: path.resolve(__dirname, 'package.json')
                }
            ]

        }),
    ],
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, process.env.outputPath || 'dist')
    }
};

