import App from "./src/app";
import {ServerConfig} from "./src/interfaces/app.interface";
import ContactUsRoute from "./src/routes/contactUs.route";
import ImageRoute from "./src/routes/image.route";
import * as config from "./src/config/config";

const serverConfig: ServerConfig = {
    HTTP_PORT: 8001,
    HTTPS_PORT: 8443,
    sslKeyPath: config.SSL_PATH_PRIVATE_KEY,
    sslCertPath: config.SSL_PATH_CERTIFICATE
}

async function main() {
    const app = new App([
        new ContactUsRoute(),
        new ImageRoute()
    ], serverConfig);

    await app.start();
}

main().then(() => {
    console.log("App started successfully");
}).catch((error) => {
    console.error("Error starting the app:", error);
    process.exit(1);
})