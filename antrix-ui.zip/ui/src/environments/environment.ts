export const environment = {
  version: '0.1.19.20240809',
};
