import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-product-service-layout',
  templateUrl: './product-service-layout.component.html',
  styleUrls: ['./product-service-layout.component.scss']
})
export class ProductServiceLayoutComponent {
}
