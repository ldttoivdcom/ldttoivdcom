export interface Regulations {
  WebLinks: string;
  Regulations: string;
  href: string;
}
