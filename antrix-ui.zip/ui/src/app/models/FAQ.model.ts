export interface FAQ {
  question: string;
  answer: string;
  answerList: string;
}
