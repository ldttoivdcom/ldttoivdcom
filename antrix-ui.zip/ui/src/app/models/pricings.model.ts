export interface Pricings {
  header: string;
  price: number;
  text: string;
  listItems: string[];
  headerAndprice: string;
  partNo?: string;
}
