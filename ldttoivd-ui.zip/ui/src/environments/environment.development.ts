export const environment = {version: '0.0.24.20231128'};
