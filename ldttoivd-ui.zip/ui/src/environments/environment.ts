export const environment = {
  version: '0.1.56.20241010',
};
