export interface Member {
  imgPath: string;
  name: string;
  title: string;
  description: string;
}
