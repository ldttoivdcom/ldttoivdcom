export interface Products {
  PartNumber: string;
  Name: string;
  imgPath: string;
  Description: string;
  Header: string;
  List: string;
  Footer: string;
}
